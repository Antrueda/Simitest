<?php
//app/Helpers/Envato/User.php
namespace App\Helpers\Traductor;

use App\Models\Sistema\SisTitulo;
use Illuminate\Support\Facades\DB;
 
class Traaas {
    /**
     * @param int $user_id User-id
     * 
     * @return string
     */
    
    public static function Sit() {
       
       
    
        return [];
    }
}