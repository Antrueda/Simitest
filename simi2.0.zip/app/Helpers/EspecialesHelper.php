<?php

namespace app\Helpers;


class IndicadorHelper
{
    private  $indicado;
    public function __construct()
    {
    }
    public static function getInArray($dataxxxx){
        $inarrayx=[];
        foreach($dataxxxx as $registro){
            if(in_array($registro->id,$inarrayx)){

            }
        }
    }
}
